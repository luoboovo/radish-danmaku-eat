# -*- coding: utf-8 -*-
import logging
from typing import *

from .clients import ws_base
from .models import web as web_models, open_live as open_models

__all__ = (
    'HandlerInterface',
    'BaseHandler',
)

logger = logging.getLogger('blivedm')

logged_unknown_cmds = {
    'COMBO_SEND',
    'DM_INTERACTION',
    'ENTRY_EFFECT',
    'HOT_RANK_CHANGED',
    'HOT_RANK_CHANGED_V2',
    'LIKE_INFO_V3_CLICK',
    'LIKE_INFO_V3_UPDATE',
    'LIVE',
    'LIVE_INTERACTIVE_GAME',
    'LOG_IN_NOTICE',
    'NOTICE_MSG',
    'ONLINE_RANK_COUNT',
    'ONLINE_RANK_TOP3',
    'ONLINE_RANK_V2',
    'ONLINE_RANK_V3',
    'PK_BATTLE_END',
    'PK_BATTLE_FINAL_PROCESS',
    'PK_BATTLE_PROCESS',
    'PK_BATTLE_PROCESS_NEW',
    'PK_BATTLE_SETTLE',
    'PK_BATTLE_SETTLE_USER',
    'PK_BATTLE_SETTLE_V2',
    'POPULAR_RANK_CHANGED',
    'POPULARITY_RED_POCKET_START',
    'POPULARITY_RED_POCKET_V2_WINNER_LIST',
    'POPULARITY_RED_POCKET_WINNER_LIST',
    'PREPARING',
    'RANK_CHANGED_V2',
    'ROOM_REAL_TIME_MESSAGE_UPDATE',
    'STOP_LIVE_ROOM_LIST',
    'SUPER_CHAT_MESSAGE_JPN',
    'USER_TOAST_MSG',
    'WATCHED_CHANGE',
    'WIDGET_BANNER',
}
"""已打日志的未知cmd"""


class HandlerInterface:
    """
    直播消息处理器接口
    """

    def handle(self, client: ws_base.WebSocketClientBase, command: dict):
        raise NotImplementedError

    def on_client_stopped(self, client: ws_base.WebSocketClientBase, exception: Optional[Exception]):
        """
        当客户端停止时调用。可以在这里close或者重新start
        """


def _get_valid_method(handler: 'BaseHandler', method_name):
    method = getattr(handler, method_name)
    cls = type(handler)
    is_noop_dict = getattr(cls, '__is_noop__', None)
    if is_noop_dict is None:
        is_noop_dict = {}
        cls.__is_noop__ = is_noop_dict

    is_noop = is_noop_dict.get(method_name, None)
    if is_noop is None:
        unbound_method = getattr(method, '__func__', method)
        base_method = getattr(BaseHandler, method_name)
        is_noop = unbound_method is base_method
        is_noop_dict[method_name] = is_noop

    if is_noop:
        # 基类方法无操作，就不用解析消息了
        return None
    return method


def _make_msg_callback(method_name, message_cls):
    def callback(self: 'BaseHandler', client: ws_base.WebSocketClientBase, command: dict):
        method = _get_valid_method(self, method_name)
        if method is None:
            return None
        return method(client, message_cls.from_command(command['data']))
    return callback


class BaseHandler(HandlerInterface):
    """
    一个简单的消息处理器实现，带消息分发和消息类型转换。继承并重写_on_xxx方法即可实现自己的处理器
    """

    def __danmu_msg_callback(self, client: ws_base.WebSocketClientBase, command: dict):
        method = _get_valid_method(self, '_on_danmaku')
        if method is None:
            return None
        return method(client, web_models.DanmakuMessage.from_command(command['info']))

    def __danmu_msg_mirror_callback(self, client: ws_base.WebSocketClientBase, command: dict):
        method = _get_valid_method(self, '_on_danmaku')
        if method is None:
            return None
        message = web_models.DanmakuMessage.from_command(command['info'])
        message.is_mirror = True
        return method(client, message)

    def __open_dm_mirror_callback(self, client: ws_base.WebSocketClientBase, command: dict):
        method = _get_valid_method(self, '_on_open_live_danmaku')
        if method is None:
            return None
        # 跨房弹幕可能缺少一些字段，详情参考官方文档
        message = open_models.DanmakuMessage.from_command(command['data'])
        message.is_mirror = True
        return method(client, message)

    def __send_gift_v2_callback(self, client: ws_base.WebSocketClientBase, command: dict):
        method = _get_valid_method(self, '_on_gift')
        if method is None:
            return
        messages = web_models.GiftMessage.batch_from_command_v2(command['data'])
        for message in messages:
            method(client, message)

    _CMD_CALLBACK_DICT: Dict[
        str,
        Optional[Callable[
            ['BaseHandler', ws_base.WebSocketClientBase, dict],
            Any
        ]]
    ]
    """cmd -> 处理回调"""
    _CMD_CALLBACK_DICT = {
        # 收到心跳包，这是blivedm自造的消息，原本的心跳包格式不一样
        '_HEARTBEAT': _make_msg_callback('_on_heartbeat', web_models.HeartbeatMessage),
        # 弹幕
        # go-common\app\service\live\live-dm\service\v1\send.go
        'DANMU_MSG': __danmu_msg_callback,
        'DANMU_MSG_MIRROR': __danmu_msg_mirror_callback,
        # 礼物
        'SEND_GIFT': _make_msg_callback('_on_gift', web_models.GiftMessage),
        # 礼物（2026-07 灰度的新协议，protobuf 编码）
        'SEND_GIFT_V2': __send_gift_v2_callback,
        # 上舰
        'GUARD_BUY': _make_msg_callback('_on_buy_guard', web_models.GuardBuyMessage),
        # 另一个上舰消息
        'USER_TOAST_MSG_V2': _make_msg_callback('_on_user_toast_v2', web_models.UserToastV2Message),
        # 醒目留言
        'SUPER_CHAT_MESSAGE': _make_msg_callback('_on_super_chat', web_models.SuperChatMessage),
        # 删除醒目留言
        'SUPER_CHAT_MESSAGE_DELETE': _make_msg_callback('_on_super_chat_delete', web_models.SuperChatDeleteMessage),
        # 进入房间、关注主播等互动消息
        'INTERACT_WORD_V2': _make_msg_callback('_on_interact_word_v2', web_models.InteractWordV2Message),

        #
        # 开放平台消息
        #

        # 弹幕
        'LIVE_OPEN_PLATFORM_DM': _make_msg_callback('_on_open_live_danmaku', open_models.DanmakuMessage),
        'LIVE_OPEN_PLATFORM_DM_MIRROR': __open_dm_mirror_callback,
        # 礼物
        'LIVE_OPEN_PLATFORM_SEND_GIFT': _make_msg_callback('_on_open_live_gift', open_models.GiftMessage),
        # 上舰
        'LIVE_OPEN_PLATFORM_GUARD': _make_msg_callback('_on_open_live_buy_guard', open_models.GuardBuyMessage),
        # 醒目留言
        'LIVE_OPEN_PLATFORM_SUPER_CHAT': _make_msg_callback('_on_open_live_super_chat', open_models.SuperChatMessage),
        # 删除醒目留言
        'LIVE_OPEN_PLATFORM_SUPER_CHAT_DEL': _make_msg_callback(
            '_on_open_live_super_chat_delete', open_models.SuperChatDeleteMessage
        ),
        # 点赞
        'LIVE_OPEN_PLATFORM_LIKE': _make_msg_callback('_on_open_live_like', open_models.LikeMessage),
        # 进入房间
        'LIVE_OPEN_PLATFORM_LIVE_ROOM_ENTER': _make_msg_callback('_on_open_live_enter_room', open_models.RoomEnterMessage),
        # 开始直播
        'LIVE_OPEN_PLATFORM_LIVE_START': _make_msg_callback('_on_open_live_start_live', open_models.LiveStartMessage),
        # 结束直播
        'LIVE_OPEN_PLATFORM_LIVE_END': _make_msg_callback('_on_open_live_end_live', open_models.LiveEndMessage),
    }

    def handle(self, client: ws_base.WebSocketClientBase, command: dict):
        cmd = command.get('cmd', '')
        pos = cmd.find(':')  # 2019-5-29 B站弹幕升级新增了参数
        if pos != -1:
            cmd = cmd[:pos]

        if cmd not in self._CMD_CALLBACK_DICT:
            # 只有第一次遇到未知cmd时打日志
            if cmd not in logged_unknown_cmds:
                logger.warning('room=%d unknown cmd=%s, command=%s', client.room_id, cmd, command)
                logged_unknown_cmds.add(cmd)
            return

        callback = self._CMD_CALLBACK_DICT[cmd]
        if callback is not None:
            callback(self, client, command)

    def _on_heartbeat(self, client: ws_base.WebSocketClientBase, message: web_models.HeartbeatMessage):
        """收到心跳包"""

    def _on_danmaku(self, client: ws_base.WebSocketClientBase, message: web_models.DanmakuMessage):
        """弹幕"""

    def _on_gift(self, client: ws_base.WebSocketClientBase, message: web_models.GiftMessage):
        """礼物"""

    def _on_buy_guard(self, client: ws_base.WebSocketClientBase, message: web_models.GuardBuyMessage):
        """上舰"""

    def _on_user_toast_v2(self, client: ws_base.WebSocketClientBase, message: web_models.UserToastV2Message):
        """另一个上舰消息"""

    def _on_super_chat(self, client: ws_base.WebSocketClientBase, message: web_models.SuperChatMessage):
        """醒目留言"""

    def _on_super_chat_delete(self, client: ws_base.WebSocketClientBase, message: web_models.SuperChatDeleteMessage):
        """删除醒目留言"""

    def _on_interact_word_v2(self, client: ws_base.WebSocketClientBase, message: web_models.InteractWordV2Message):
        """进入房间、关注主播等互动消息"""

    #
    # 开放平台消息
    #

    def _on_open_live_danmaku(self, client: ws_base.WebSocketClientBase, message: open_models.DanmakuMessage):
        """弹幕"""

    def _on_open_live_gift(self, client: ws_base.WebSocketClientBase, message: open_models.GiftMessage):
        """礼物"""

    def _on_open_live_buy_guard(self, client: ws_base.WebSocketClientBase, message: open_models.GuardBuyMessage):
        """上舰"""

    def _on_open_live_super_chat(self, client: ws_base.WebSocketClientBase, message: open_models.SuperChatMessage):
        """醒目留言"""

    def _on_open_live_super_chat_delete(
        self, client: ws_base.WebSocketClientBase, message: open_models.SuperChatDeleteMessage
    ):
        """删除醒目留言"""

    def _on_open_live_like(self, client: ws_base.WebSocketClientBase, message: open_models.LikeMessage):
        """点赞"""

    def _on_open_live_enter_room(self, client: ws_base.WebSocketClientBase, message: open_models.RoomEnterMessage):
        """进入房间"""

    def _on_open_live_start_live(self, client: ws_base.WebSocketClientBase, message: open_models.LiveStartMessage):
        """开始直播"""

    def _on_open_live_end_live(self, client: ws_base.WebSocketClientBase, message: open_models.LiveEndMessage):
        """结束直播"""
